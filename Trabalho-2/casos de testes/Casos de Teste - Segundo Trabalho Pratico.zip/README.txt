Arquivo zip gerado em: 30/10/2020 22:08:37 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Segundo Trabalho Prático